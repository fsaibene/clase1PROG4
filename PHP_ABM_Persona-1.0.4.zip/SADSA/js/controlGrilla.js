
     
		function Borrar(id)
		{
			document.getElementById('dniParaBorrar').value = id;
			document.frmBorrar.submit();
		}
		function Modificar(id)
		{
			document.getElementById('dniParaModificar').value = id;
			document.frmModificar.submit();
		}
   